The main file is main2.cpp.
Run the main2.cpp file to see the search engine.

article_remove.cpp removes the article from the search query.

match_find.cp holds the substring match function.

permmute.cpp holds the function of permutation of the search query.

(0,9).txt files are my documents where the search engine searches.